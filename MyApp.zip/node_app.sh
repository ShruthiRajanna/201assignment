nohup npm install  --prefix MyApp/ > /dev/null 2>&1 &
nohup npm start  --prefix MyApp/ > /dev/null 2>&1 &
